---
name: "1688-findchain"
description: "1688 找品链：1688-cli research+工厂过滤+enrich阶梯价+BSR背调+综合分排序输出表格。"
triggers:
  - "1688找品"
  - "找品链"
  - "搜1688商品"
  - "1688供应商背调"
  - "1688阶梯价"
l1: 电商平台
l2: 1688
l3: 找品链
---

# 1688 找品链

## 核心能力
调用 `1688-cli research` 命令，在已登录的 1688 账号下搜索商品，
自动过滤工厂（`--verified factory`）、江浙沪地区（`--province`），
enrich 前 N 个详情页抠出**阶梯价**和**供应商 BSR**（回头率/年限/服务标签），
输出按综合分排序的 markdown 表格。

## 前置条件
- `1688-cli` 已安装：`npm install -g 1688-cli --registry=https://registry.npmmirror.com`
- 已扫码登录：`1688 login`（已扫，账号 罗庆富，登录态在 `~/.1688/`）

## 用户风格（2026-07-31 确认）
- **不解释过程，直接给结果**：用户说「我要的是结果，你怎么实现是你的事」，不要汇报过程、工具选择、失败尝试
- 输出只放最终结果表格，不放中间分析
- 用户问「怎么办」时，直接给选项和推荐，不问确认

## 使用方式（直接说「找品 关键词」即可触发）
```bash
# 标准找品（默认浙江+工厂+排除广告）
python3 ~/findchain.py "20x20x10cm纸箱"

# 指定省份
python3 ~/findchain.py "关键词" --province 江苏

# 指定最大结果数
python3 ~/findchain.py "关键词" --max 30
```

## findchain.py 核心逻辑
```python
cmd = [
    "1688", "research", KEYWORD,
    "--max-per-query", "20",
    "--verified", "factory",       # 丢贸易商，只留工厂
    "--province", "浙江",          # 江浙沪优先
    "--exclude-ads",              # 排除 P4P 广告
    "--enrich", "top:10",         # enrich 前 10 个详情页（阶梯价+BSR）
    "--jsonl"
]
```

## 输出字段
| 字段 | 说明 |
|------|------|
| 排名 | globalRank（综合分排序） |
| 商品链接 | 1688 桌面详情页 URL |
| 商品标题 | 前 40 字符 |
| 价格 | 阶梯价（≥N件 ¥X），enrich 后才有 |
| 供应商 | 工厂名称 |
| 地区 | 省+市 |
| 年限 | 供应商年限 |
| 工厂标 | ✅工厂（1688 认证） |
| 服务标签 | 退货包运费/后天达/先采后付 |
| 销量 | 近 30 天订单数 |
| 综合分 | 1688-cli 内置打分（价格+需求+年限+验证+服务标签） |

### ⚠️ 1688 滑块验证码：browser 自动化无法通过（2026-07-31 确认）

**症状**：在已登录的 Chrome 里用 `browser_navigate` 打开 1688 首页 → 在搜索框输入关键词 → 按 Enter → 页面显示"亲，请拖动下方滑块完成验证"。

**触发场景**：
- `browser_navigate('https://www.1688.com/')` → 输入搜索词 → Enter → 触发滑块验证
- 即使是已继承登录态的 profile-mirror Chrome，搜索提交后仍触发

**根本原因**：1688 搜索请求（`s.1688.com/youyuan/index.htm`）在检测到非人类操作模式时，触发 AliWangWang 滑块验证码。这是服务端防御机制，CDP `Runtime.evaluate` + `Input.dispatchMouseEvent` 无法通过。

**HTTP API 同样受阻**：`/youyuan/fenlei/search.json` 在未验证的 session 里直接重定向到 login.1688.com。

**对 findchain 的影响**：1688-cli 的 `research`/`search` 底层调用的也是 1688 搜索 API，daemon 暂停（DAEMON_PAUSED）可能就是验证 token 过期导致的。

**已验证的可绕过路线**：
1. **web_search** → 找 `site:detail.1688.com` 商品链接 → `browser_navigate` → 详情页（详情页**不触发验证码**，可正常提取规格/价格）
2. **用户人工绕过**：在 Chrome 里手工完成一次滑块验证，之后该 session 短期有效
3. **Cookie 维护**：从已验证浏览器提取 Cookie 注入脚本（有有效期，不稳定）

**1688 搜索正确工作流（修订版）**：
1. `web_search("site:detail.1688.com 关键词")` → 拿商品 offer ID
2. `browser_navigate("https://detail.1688.com/offer/{id}.html")` → 详情页无验证码
3. CDP 提取规格表 + 阶梯价

### ⚠️ 1688搜索列表页 — iframe 隔离已失效（2026-07-31 修正）
> ⚠️ 之前记录的 iframe 隔离问题**已于 2026-07-31 确认失效**：1688 搜索结果现已直接渲染在主 DOM，`Runtime.evaluate` 在搜索 tab 上直接能读到 `a[href*="offerId="]` 的 offer ID，不再需要 iframe 跨域处理。

~~1688 搜索结果渲染在**深层 iframe** 里...~~

**实测可用工作流（已简化）**：
1. 用户在 Chrome 地址栏输入 `s.1688.com` + 关键词搜索
2. `browser_cdp` → `Runtime.evaluate` → 搜索 tab 上直接提取所有 `a[href*="offerId="]` 的 offer ID
3. 用 `Target.createTarget` 逐个打开商品详情页（详情页没有 iframe 隔离，能抓到价格/规格）

### ⚠️ 1688-cli Daemon 暂停机制（2026-07-31 新发现）
`1688-cli` 内部有防刷机制，连续调用后会触发 `DAEMON_PAUSED`：

```
{"ok": false, "code": "DAEMON_PAUSED", "message": "Daemon for profile "default" is paused until 2026-07-31T03:59:04Z"}
```

- 影响：`search` 返回 `[]`，`research` 也失败
- 恢复：等约 10 分钟 UTC，或换 CDP + 用户 Chrome 实时搜索
- **不要**把 1688-cli 当主力实时搜索；CDP + 用户 Chrome 才是实时搜索，1688-cli 用于 detail 结构提取

### ⚠️ 省分筛选 URL 参数不生效（2026-07-28 确认）
`province=金华市` 或 `province=浙江` 加在 1688 搜索 URL 里**不能**真正过滤地区。

**正确方式**：在 Chrome 浏览器里手动点击「更多筛选」→「地区选择」→ 勾选目标省市。

### ⚠️ findchain.py 作为搜索列表来源的局限性（2026-07-28 确认）
- `findchain.py` 超时严重（55s+），且 province 参数不生效
- 搜索结果与用户本地 Chrome 看到的不同步
- **禁止**用 findchain.py 代替用户本地浏览器搜索
### CDP 读页面实际价格的稳定方法
```python
# 用 Target.createTarget 开详情页（新 tab 是干净的，能正常渲染）
send(ws, "Target.createTarget", {"url": f"https://detail.1688.com/offer/{oid}.html"})
# 等渲染
time.sleep(5)
# 直接读价格和规格（1688 详情页没有 iframe 隔离）
send(ws, "Runtime.evaluate", {
    "expression": "(function(){var t=document.title; var p=document.body.innerText.match(/¥[\\s\\d.]+/g); return JSON.stringify({title:t, price:p?p.slice(0,5):[]});})()",
    "returnByValue": True
})
```

### Google 搜索 CAPTCHA
Google 搜索对自动化浏览器会触发 CAPTCHA，1688-cli 和 web_search 走的是后端 API 不受影响。
**不要**在 CDP 控制的 Chrome 里用 `browser_navigate` 或 `Page.navigate` 打开 Google 搜索 URL，会被立即拦截。

## A/B 双路线
- **B（1688-cli）主力**：结构化 BSR 背调、阶梯价、工厂过滤、分值排序，搜索列表用它
- **A（CDP 兜底）**：逐个打开详情页抠规格/价格时用它（`Target.createTarget` → 详情页）

- **1688滑块验证码**：见 `references/1688-slider-captcha-20260731.md`
- **1688详情页价格验证**：见 `references/price-verification.md`

## 文件位置
- Wrapper: `~/findchain.py`
- A CDP 兜底脚本: `~/1688_findchain_v2.py`
- B profile: `~/.1688/`

## 输出格式铁律（用户纠正后固化）
1. **必须「商品链接 | 店铺 | 价格」三列表格**，不用存 MEDIA 文件
2. 列少（最多4列），字大，行短，链接全
3. 规格精准匹配时，价格列写精准 SKU 单价（元/个），不要写起价范围
4. 5 家起出结果，不够继续翻页扩量

## ⚠️ 用户行为铁律（2026-07-28 用户愤怒纠正后更新）

### ⚠️ 浏览器可见性铁律（2026-07-28 用户愤怒纠正后更新）

**核心问题（关键坑）**：`browser_navigate` / `browser_snapshot` / `browser_click` / `browser_press` / `browser_type` 都指向同一个固定的CDP target——Chrome启动时创建的background CDP session，**不是用户屏幕上看到的Chrome窗口**。

用户屏幕上的窗口：`is_on_screen: true`（用 `cua-driver list` 查看），与 `browser_navigate` 指向的不是同一个tab。

**表现**：
- `browser_navigate("https://www.1688.com")` → URL确实变了，title也变了，但你用 `browser_vision` 拍截图或用户看屏幕，页面没变
- `browser_snapshot` 里出现 `chrome://newtab/` 但用户看到的是另一个页面
- `browser_cdp` 用 `Runtime.evaluate` 读 `window.location.href` 返回的是旧tab的URL，不是当前显示页面的URL

**正确做法——用 CDP 创建新tab绑定到用户窗口**：
1. 用 `cua-driver call list_windows` 找到用户眼前窗口的 tab id（如 `is_on_screen: true` 的那个）
2. 用 `browser_cdp` → `Target.createTarget` 在那个窗口里创建新tab（`target_id` 填用户眼前tab的id）
3. 之后所有 `browser_navigate` / `browser_snapshot` / `browser_click` 操作就自动路由到这个新tab
4. **验证方法**：每步操作后用 `browser_cdp` → `Runtime.evaluate` → `window.location.href` 确认当前tab URL是否是你要的那个

```python
# Step 1: 找到用户眼前的Chrome tab
# cua-driver call list_windows | grep Chrome
# 找 is_on_screen: true 的那个，记下 tab id（如 "362BD38D..."）

# Step 2: 在那个窗口里新建一个tab
browser_cdp(method="Target.createTarget", params={"url": "about:blank"}, target_id="用户眼前tab的id")
# 返回新的 target_id（如 "0CBDD08D..."）

# Step 3: 之后 browser_navigate 就自动路由到这个新tab
browser_navigate(url="https://www.1688.com")  # 用户终于能在屏幕上看到了

# Step 4: 验证
browser_cdp(method="Runtime.evaluate", params={"expression": "window.location.href"}, target_id="新tab的id")
# 确认为 https://www.1688.com/ 才是对的
```

**禁止**：
- 用 `computer_use`（cua-driver）代替 `browser_navigate` 做浏览器导航——`computer_use` 控制macOS窗口，不能控制Chrome标签页
- 用 `findchain.py` / `web_search` 代替浏览器搜索——用户要看到屏幕上的搜索结果

### 1688 搜索页 iframe 隔离已解决（2026-07-28）
之前以为搜索结果在 iframe 里无法提取，实测用上述「新tab绑定」方法后，1688 搜索结果**直接渲染在主DOM里**，不需要处理 iframe。

### 搜索方式
- 1688 搜索：用户在浏览器上看到搜索框 → `browser_navigate` 打开 1688 搜索 URL → 用户在屏幕上看到结果 → 用户告诉你点哪个商品 → CDP 打开详情页
- **不要**在 CDP 新 tab 里导航到 1688 搜索页然后用 JS 提取（iframe 隔离，会拿到空结果）
- 省分筛选在浏览器里手动操作（点「更多筛选」→「地区」）不要试图用 URL 参数

## 铁律（来自用户两次纠正）
### 输出格式铁律（用户纠正后固化）
1. **必须「商品链接 | 店铺 | 价格」三列表格**，不用存 MEDIA 文件
2. 列少（最多4列），字大，行短，链接全
3. 规格精准匹配时，价格列写精准 SKU 单价（元/个)，不要写起价范围
4. 5 家起出结果，不够继续翻页扩量

## 规格精准核验流程（重要补充）
用户说「我要 XX*XX*XXcm」时，1688-cli 列表**无法验证规格是否精确匹配**，必须逐个核验：

### 工作流
1. **Chrome 搜索 tab 设置省分 + 规格关键词** → CDP 读 offerId 列表
2. `1688-cli offer detail {offerId}` → 筛选含目标规格的 SKU
3. 命中 < 5 家时继续翻页扩量（除非全网就只有这几家）

### ⚠️ 价格铁律：JSON 价格 ≠ 页面实际价格，必须用 CDP 读页面
`1688-cli offer detail` JSON 接口返回的 `skus[].price` 是**历史缓存价**，与页面实时展示的阶梯价可能相差 2-5 倍。
本 session 案例：`offer 634522031289` JSON 报 `¥0.8`，页面实际 `¥0.2`（相差 4 倍）。

**正确流程：**
1. `1688-cli offer detail {offerId}` 筛选含目标规格的 SKU → 找 offerId 列表
2. CDP 导航到 `https://detail.1688.com/offer/{oid}.html` → 点击目标规格按钮 → 读 `.od-price-container` 或 `.price-comp` 的 `innerText`
3. 取页面实际展示的阶梯价填入结果表

### CDP 读页面实际价格的稳定方法
```python
# 1. 导航到商品页，等待渲染
send(ws, "Page.navigate", {"url": f"https://detail.1688.com/offer/{oid}.html"})
time.sleep(5)

# 2. 点击目标规格（button innerText 精确匹配）
send(ws, "Runtime.evaluate", {
    "expression": "var btns=document.querySelectorAll('button');for(var b of btns){if(b.innerText.trim()==='16*16*16cm'){b.click();break}}'clicked'",
    "returnByValue": True
})
time.sleep(2)

# 3. 读价格组件（稳定位置）
send(ws, "Runtime.evaluate", {
    "expression": "(function(){var c=document.querySelector('.od-price-container, .price-comp');return c?c.innerText.trim().replace(/\\n+/g,' '):'not found';})()",
    "returnByValue": True
})
# 典型输出: "¥ 0 .20 ¥ 10 .81 1个起批 60天老客价"
```

### CDP 控制 Chrome 搜索 tab 拿 offerId 列表（比 1688-cli 更准）
1688-cli 的 `--province` 参数与 Chrome 手动设置的「省分过滤」结果**不同步**。
Chrome 手动设好省分+关键词后，用 CDP 拿 offerId：

```python
TAB_ID = "F246394BA9811014DC348E00BED9BBEE"  # 从 curl http://127.0.0.1:9222/json 获取
BASE = "http://127.0.0.1:9222"
import json, urllib.request, websocket, time
targets = json.loads(urllib.request.urlopen(f"{BASE}/json", timeout=10).read())
tinfo = next(t for t in targets if t["id"] == TAB_ID)
ws = websocket.create_connection(tinfo["webSocketDebuggerUrl"], timeout=30)

# 搜索结果页导航
send(ws, "Runtime.enable"); time.sleep(1)
send(ws, "Page.navigate", {"url": "https://s.1688.com/youyuan/index.htm?keywords=关键词&province=浙江"})
time.sleep(6)

# 提取 offerId
send(ws, "Runtime.evaluate", {
    "expression": """
(function(){
    var links = document.querySelectorAll('a[href*="offer/"]');
    var ids = [];
    for(var a of links){
        var m = a.href.match(/offer\\/(\\d+)/);
        if(m && ids.indexOf(m[1])<0) ids.push(m[1]);
    }
    return ids.join(',');
})()
    """,
    "returnByValue": True
})
```

### 省分过滤器铁律（用户纠正，2026-07-28 确认失效）
- **1688-cli 的 `--province` 参数不可靠**——与 Chrome 手动设置的省分过滤结果不同步
- **province URL 参数不生效**——加在搜索 URL 里不能真正过滤地区
- Chrome 里手动设置省分为「浙江/金华」+ 搜索关键词 → 用户看屏幕选商品 → CDP 逐个打开详情页核验规格和价格
- 1688-cli 适合做**详情页结构化数据提取**（offer detail），不适合作为搜索结果来源

### 全网不足 5 家的处理
当翻完全部搜索结果（翻到无下一页）后命中仍 < 5 家时：
- 在结果表后注明「全网（金华/义乌）仅 X 家有该规格现货」
- 提供「接近规格」选项供用户选择（如 15×15×15cm、16×16×11cm）
- 或提示「定做」路线
