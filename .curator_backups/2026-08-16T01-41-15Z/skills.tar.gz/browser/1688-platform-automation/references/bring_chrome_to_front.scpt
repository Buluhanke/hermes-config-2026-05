tell application "Google Chrome"
    activate
    set visible of window 1 to true
    set bounds of window 1 to {0, 0, 1440, 900}
end tell
