# 1688 搜索结果商品链接抓取（2026-07-27 实测）

## 核心障碍：点击商品 → 图片搜索劫持

**现象**：点击搜索结果中的商品卡片 → 跳转到 `air.1688.com/kapp/1688-search/pc-image-search/`（图片搜索页），不是商品详情页。

**1688 的劫持行为**：
- 搜索结果列表中的商品链接经过 1688 中间层跳转
- 点击时 1688 判断来源为搜索列表 → 优先打开图片搜索（比直接打开商品详情更容易触发再访问）
- 这个问题在 CDP 控制和手动操作都会出现

**已验证可行的解法**：

### 解法 A：商品 ID 构造法（最可靠）
1. 从搜索结果页提取 offer ID（CDP evaluate 拿不到，但可从页面 HTML 提取）
2. 直接用 offer ID 构造详情页 URL：`https://detail.1688.com/offer/{offer_id}.html`
3. 用 `browser_navigate` 或 CDP `Page.navigate` 打开详情页

### 解法 B：用 CDP `Runtime.evaluate` 在搜索结果页提取所有 offer URL
```javascript
(function(){
  var as = document.querySelectorAll('a');
  var results = [];
  for(var i=0; i<as.length; i++){
    var href = as[i].href;
    // 匹配 offer ID 格式
    if(href && href.match(/detail\.1688\.com\/offer\/\d+\.html/)){
      results.push(href);
    }
  }
  return JSON.stringify(results.slice(0, 20));
})()
```
**注意**：2026-07-27 实测在搜索结果页执行此脚本返回空数组 `[]`——1688 的 offer 链接在搜索结果页不是标准 `<a href>` 格式，而是 JS 动态绑定，CDP evaluate 拿不到。

### 解法 C：搜索结果页不可靠，改用店铺页
1. 搜索关键词 + 地区筛选
2. 找目标店铺的店铺首页 URL（1688 店铺页 URL 相对稳定）
3. 在店铺首页提取商品列表

## 搜索结果页不稳定问题（CDP 环境特有问题）

**现象**：搜索成功后，搜索结果页内容会随机变回默认状态（热门推荐/非关键词结果），即使没有进行任何导航操作。

**可能原因**：
- 1688 检测到 CDP 自动化特征，降低内容可信度
- Session 状态不一致，1688 做了降级处理

**已验证可行的解法**：
- 搜索完成后立即提取当前页所有商品信息，不要依赖后续操作
- 不要在 CDP 控制的 1688 搜索页上做多步操作，每一步都可能触发页面重置

## 实测有效的商品详情页规格读取脚本

```javascript
(function(){
  var text = document.body.innerText;
  var hasTarget = text.includes('20*20*10') || 
                  text.includes('20x20x10') || 
                  text.includes('20×20×10');
  var specs = '';
  var specMatch = text.match(/规格[\s\S]{0,2000}/);
  if(specMatch) specs = specMatch[0].substring(0, 1000);
  var priceMatch = text.match(/¥\s*(\d+\.\d+)/);
  var price = priceMatch ? priceMatch[1] : 'not found';
  return JSON.stringify({
    hasTarget: hasTarget,
    price: price,
    specs: specs,
    title: document.title.substring(0, 80)
  });
})()
```

## 1688 offer ID 格式
- 格式：`detail.1688.com/offer/{12-14位数字}.html`
- 示例：`https://detail.1688.com/offer/998552191936.html`
- 从搜索结果提取：可通过浏览器开发者工具 Network 面板过滤 `detail.1688.com` 请求

## 江浙沪地区关键词（过滤用）

| 地区 | 城市关键词 |
|------|-----------|
| 浙江 | 义乌、金华、杭州、温州、宁波、台州、绍兴、嘉兴、湖州 |
| 江苏 | 苏州、南京、无锡、常州、南通、扬州、徐州、盐城 |
| 上海 | 上海 |

优先级：义乌/金华 > 杭州/苏州/上海 > 其他江浙沪城市
