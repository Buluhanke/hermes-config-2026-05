# 1688 双轨操作路径（2026-07-31 实操确认）

> 核心认知：用户说「用本地浏览器/用你的Chrome」时，有两条完全不同的路。走错了一条，用户就看不到任何变化，然后抱怨「为什么停住了」。

## 路径 A — 用户可见 Chrome（`computer_use`）

**控制的是什么**：用户桌面上那个 Chrome 窗口（肉眼可见）
**操作方式**：`computer_use capture` + `click`/`type`/`key` → 用户亲眼看到变化
**典型场景**：
- 在地址栏输入 URL 并导航
- 点击搜索框、输入关键词、点搜索按钮
- 滚动页面、点击商品卡片
- 任何需要用户视觉确认的操作

**操作序列**：
```
computer_use(apture, app="Google Chrome") 
→ computer_use(key, "cmd+l")          # 全选地址栏
→ computer_use(type, "https://...")  # 输入 URL
→ computer_use(key, "return")        # 回车导航
```

**验证方法**：用户能在屏幕上看到浏览器窗口内容变化 → 确认是路径 A

## 路径 B — 后台 CDP Chrome（`browser_navigate` / `browser_snapshot`）

**控制的是什么**：localhost:9222 端口的后台 Chrome 实例（用户看不见）
**操作方式**：`browser_navigate` → `browser_snapshot` / `browser_cdp` → 返回结构化数据
**典型场景**：
- 直接打开商品详情页 `detail.1688.com/offer/{id}.html`
- 提取规格表、价格表（`browser_snapshot` 返回完整 AX tree）
- CDP 执行 JS 读页面数据
- `browser_console` 读当前页面控制台

**关键限制**：
- 1688 搜索列表页在深层 iframe 里，CDP 的 `Runtime.evaluate` 对搜索页 iframe 注入 JS 返回空数组（`[]`）—— 无法提取 offer ID
- `browser_console` 连接的是首页（`www.1688.com`），不是当前用户可见的搜索 tab
- 切换 CDP tab 需要从 `Target.getTargets` 获取正确的 `target_id`

**验证方法**：`browser_navigate` 后 URL 变了、title 变了，但用户屏幕毫无变化 → 这是路径 B，用户看不见

## 关键教训（为什么之前「停住了」）

| 错误认知 | 正确认知 |
|---------|---------|
| 「我打开了 Chrome」 | `browser_navigate` 开的是后台 Chrome，用户屏幕没变化 |
| 「用你的 Chrome」= 开一个新的 | 用户指的是他屏幕上那个，不是后台另一个 |
| 路径 A 和路径 B 可以混用 | 两者独立，各有端口，各有登录态，不能互替 |
| `computer_use` 能看见所有页面元素 | **搜索结果在深层 iframe 里，`computer_use` 的 AX tree 同样看不见 iframe 内部商品链接** |
| 翻译弹窗点不掉 | 弹窗覆盖在所有元素上方，先关弹窗再操作页面 |

## ⚠️ Google Translate 扩展弹窗（2026-07-31 新增坑点）

Google Translate Chrome 扩展在**每个页面加载时**都会弹出翻译提示（"翻译此页？"），覆盖在主窗口上方，完全挡住交互。

**症状**：
- AX tree 里看到 `AXWindow '翻译此页？'` 覆盖在主窗口上方
- 所有点击都被弹窗截获，element 索引在弹窗消失后错位
- 每次 `open -a "Google Chrome" --url` 或页面刷新后必出现

**解法（按优先级）**：
1. **用户手动永久关掉**：扩展图标 → 选项 → 关闭该站点翻译
2. **快捷键**：`Escape` 有时能关掉
3. **坐标点击关闭按钮**：弹窗关闭按钮在 AX tree 里是 `element=4`，直接 `computer_use click element=4`
4. **隔离 Chrome 实例**：用没有翻译扩展的 profile 运行自动化（但需单独处理登录态）

## 终极解法：两条路都不通时用 1688-cli

当路径 A（`computer_use` 点击 iframe 内商品）和路径 B（CDP 搜索页 iframe JS 注入）都不通时，用 `1688-cli` 完全绕过浏览器：
```bash
1688 research "16*16*16cm纸箱" --verified factory --province 浙江 --enrich top:10 --jsonl
```
1688-cli 使用独立 Chrome profile + 独立端口，与 `computer_use` / CDP 控制的 Chrome 完全不冲突。

## 何时用哪条路

| 任务 | 正确路径 |
|------|--------|
| 用户说「打开1688，搜索XX」 | 路径 A（用户可见 Chrome 操作搜索框） |
| 搜索结果出来了，要逐个点开商品 | 路径 A（点击商品）→ 路径 B（读详情页数据） |
| 只想读商品详情/规格/价格 | 路径 B（`browser_navigate` 到详情页 → `browser_snapshot`） |
| 搜索结果页 iframe 里拿不到 offer ID | 放弃从 CDP 搜索页提取，改为路径 A 点击商品，从新 tab URL 拿 offer ID |
| 用户说「停住了/没反应」 | 检查：是不是走了路径 B 但用户期待路径 A（屏幕没变化） |
