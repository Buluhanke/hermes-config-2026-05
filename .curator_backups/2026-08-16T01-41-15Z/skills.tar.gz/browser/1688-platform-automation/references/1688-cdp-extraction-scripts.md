# 1688 CDP Extraction Scripts (2026-07-31 实测可行)

## 搜索页 iframe 内提取所有商品 offer ID

执行位置：1688 搜索结果页 iframe（target_id = 搜索页 tab）
执行方式：`browser_cdp` + `Runtime.evaluate` + `target_id`

```javascript
(function(){
  var r=[];
  document.querySelectorAll('a').forEach(function(a){
    var m=a.href.match(/offerId=(\d+)/);
    if(m){
      var id=m[1];
      var txt=a.innerText.trim().replace(/\n/g,' ').slice(0,60);
      if(txt.length>5&&!r.find(function(x){return x.id===id}))
        r.push({id:id,text:txt,href:a.href})
    }
  });
  return JSON.stringify(r.slice(0,30))
})()
```

返回格式：`[{id:"736891013614",text:"16cm正方形特硬覆膜防水包装白盒...¥1.61...",href:"http://detail.m.1688.com/page/index.html?offerId=736891013614..."}]`

注意：
- 只匹配 `offerId=` 参数，不匹配 `/offer/` 路径格式
- `text` 是 innerText，含价格但需手动解析
- 已去重（同一 ID 多次出现只保留第一条）

---

## 详情页核价 JS

执行位置：1688 商品详情页（从 `Target.getTargets` 获取 target_id）
执行方式：`browser_cdp` + `Runtime.evaluate` + `target_id`

```javascript
(function(){
  var t=document.title;
  var b=document.body.innerText;
  var hasTarget=b.includes('16*16*16cm')||b.includes('16×16×16cm')||b.includes('16x16x16cm');
  var rows=[];
  document.querySelectorAll('table tr').forEach(function(row){
    var cells=Array.from(row.cells).map(function(c){return c.innerText.trim()});
    if(cells.length>0) rows.push(cells.join(' | '))
  });
  return JSON.stringify({title:t,hasTarget:hasTarget,specRows:rows.slice(0,20)})
})()
```

返回字段：
- `title`：商品标题（含供应商名）
- `hasTarget`：是否含目标尺寸（16*16*16cm）
- `specRows`：规格表所有行（可直接搜索目标尺寸行）

实测返回中山「16cm正方形」商品规格表，含完整尺寸列（16*16*8cm / 16*16*10cm / 16*16*12cm / 16*16*14cm / 16*16*16cm）。

---

## 从 Target.getTargets 找到详情页 target_id

1688 商品点击后会在新 tab 打开，通过 `browser_cdp` + `method: Target.getTargets` 获取所有 tab 列表，找 `type=page` 且 `title` 含商品名的条目，其 `targetId` 即详情页 tab ID。

也可以用商品 ID 直接拼 URL：`https://detail.1688.com/offer/{id}.html`，用 `Target.createTarget` 创建新 tab 导航过去（注意：1688 有反爬，新 tab 创建可能被拦截跳转到首页）。

---

## 快速核实供应商家地域

从详情页 `body.innerText` 找供应商名，再搜索确认。地域关键词：义乌、金华、杭州、苏州、上海（江浙沪）。不在这些区域的商品直接排除。

---

## 已知坑点

1. **Google Translate 弹窗**：每次页面加载都弹，要先关掉才能操作
2. **新 tab 被 1688 反爬拦截**：创建新 tab 跳详情页可能被拦截跳首页，用已有 tab 导航更稳
3. **详情页 innerText 包含所有尺寸**：不用单独找规格表 div，直接搜 body 文本即可
