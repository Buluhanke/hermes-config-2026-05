# 1688 找品链完整流程（登录Chrome → 逐个开商品 → 核规格 → 记录）

> 验证日期 2026-07-27，macOS + Chrome 150 登录态镜像。用户铁律：必须真实打开商品，禁止 web_search 糊弄。

## 0. 起登录态 CDP 实例（带登录态的镜像，非空白）
```bash
# 镜像真实 Profile 3（登录态在 Profile 3）
SRC="$HOME/Library/Application Support/Google/Chrome"
DST="$HOME/chrome-cdp-profile"
rsync -a --exclude 'BrowserMetrics' --exclude 'GraphiteDawnCache' --exclude '*Cache*' \
  "$SRC/Local State" "$SRC/Profile 3" "$DST/"
# zsh 坑：--remote-allow-origins=* 的 * 必须加引号，否则 "no matches found" 进程秒退
open -n -a "Google Chrome" --args \
  --remote-debugging-port=9222 "--remote-allow-origins=*" \
  --user-data-dir="$HOME/chrome-cdp-profile" \
  --no-first-run --no-default-browser-check "https://www.1688.com/"
# 关实例：pkill -9 -f "user-data-dir=/Users/aimac/chrome-cdp-profile" （绝不 pkill 所有 Chrome）
```
- 空白镜像 `/tmp/chrome-debug` 无登录态，不可用。
- 后台 `terminal(background)` 起的实例在 macOS 常脱离窗口服务器（进程在跑但无窗口）；用 `open -n` 才能弹可见 GUI 窗口。

## 1. CDP 严格 send/recv_id 配对模型
```python
import json, time, urllib.request, websocket
BASE="http://127.0.0.1:9222"
def cid():
    cid.n+=1; return cid.n
cid.n=0
def send(ws,m,p=None):
    i=cid(); ws.send(json.dumps({"id":i,"method":m,"params":p or {}})); return i
def recv_id(ws,w):
    while True:
        r=json.loads(ws.recv())
        if r.get("id")==w: return r
# 创建页 → 等 → 连 page WS → enable
ver=json.loads(urllib.request.urlopen(f"{BASE}/json/version",timeout=10).read())
bws=websocket.create_connection(ver["webSocketDebuggerUrl"],timeout=20)
i=send(bws,"Target.createTarget",{"url":url}); tid=recv_id(bws,i)["result"]["targetId"]
time.sleep(3)
t=next(x for x in json.loads(urllib.request.urlopen(f"{BASE}/json",timeout=10).read()) if x["id"]==tid)
pws=websocket.create_connection(t["webSocketDebuggerUrl"],timeout=20)
send(pws,"Runtime.enable"); recv_id(pws,cid.n)
send(pws,"Page.enable"); recv_id(pws,cid.n)
# 读值
def ev(pws,expr,sleep=0):
    if sleep: time.sleep(sleep)
    i=send(pws,"Runtime.evaluate",{"expression":expr,"returnByValue":True})
    r=recv_id(pws,i)
    return r["result"]["result"].get("value") if "result" in r and "result" in r["result"] else None
```

## 2. 搜索框真实输入（GBK 自动编码，不要 browser_navigate 带中文 URL）
```python
focus='''(function(){var b=document.querySelector('input[name=keywords]')||document.querySelector('#keyword')||document.querySelector('input.search-input');if(b){b.focus();if(b.select)b.select();return 'ok';}return 'no';})()'''
ev(pws, focus)
time.sleep(0.5)
send(pws,"Input.insertText",{"text":KEYWORD}); recv_id(pws,cid.n)   # 关键词含中文也能用
time.sleep(0.7)
for ph in ("keyDown","keyUp"):
    send(pws,"Input.dispatchKeyEvent",{"type":ph,"key":"Enter","code":"Enter","windowsVirtualKeyCode":13}); recv_id(pws,ph)
time.sleep(8)
# 重定位到搜索结果 tab（URL 含 keywords=20x20x10cm 的 GBK 编码）
```

## 3. 从推荐卡片抠 offerId（关键！卡片链接是 offerId= 形态，不是 detail.1688.com/offer/数字）
```javascript
(function(){
  var cards=document.querySelectorAll('.search-offer-wrapper, .offer-item, [class*=offer-card]');
  if(!cards.length) cards=document.querySelectorAll('a[href*="offerId="]');
  var out=[];
  for(var i=0;i<cards.length;i++){
    var c=cards[i];
    var title=(c.innerText||'').replace(/\n/g,' ').trim().slice(0,80);
    var shop=''; var sa=c.querySelector('a[href^="http://"][href*=".1688.com"]'); if(sa) shop=sa.getAttribute('href')||'';
    var offerId=''; var oa=c.querySelector('a[href*="offerId=""]');
    if(oa){var h=oa.getAttribute('href')||'';var m=h.match(/offerId=(\d+)/);if(m)offerId=m[1];}
    var price='';var pm=(c.innerText||'').match(/¥\s*(\d+\.?\d*)/);if(pm)price=pm[1];
    if(offerId)out.push({title:title,shop:shop,offerId:offerId,price:price});
  }
  return JSON.stringify({n:out.length, items:out});
})()
```

## 4. 逐个开详情页核规格 + 背调
- 拼 `https://detail.1688.com/offer/{offerId}.html`，`Page.navigate` 后等 5s，读 `document.body.innerText`。
- 尺寸命中：`new RegExp('20[ *×xX]20[ *×xX]10')` 匹配规格区文本。
- 工厂标：`/(超级工厂|牛头标|实力商家|诚信通)/`
- 代发：`/一件代发|支持代发|先采后付/` → 'Y'/'N'
- 地区：`/(义乌市?|金华市?|杭州市?|苏州市?|上海|浙江|江苏)/`
- ⚠️ 回头率/MOQ 纯文本正则剥不干净（数字与标签分离），精确值交给 1688-cli `--enrich` 或进 SKU DOM 节点抠。

## 5. 打分排序
命中目标规格(+50) + 江浙沪(+15) + 代发Y(+10) + 超级工厂(+10) + 回头率≥40%(+5)，按分降序输出短名单。

## 踩坑清单
1. 错抓空白搜索页 → `get_tab` 必须优先匹配 `keywords=你的词`（ASCII 前缀）。
2. CDP 消息不配对 → `Runtime.evaluate` 读不到值（被 enable ack 吃串）。
3. 卡片 offerId 形态 ≠ detail 链接形态 → 必须抠 offerId 再拼。
4. zsh `*` 未引号 → Chrome 进程秒退，日志无输出。
5. 后台 terminal 起的实例无可见窗口 → 用 `open -n` 拉 GUI 实例。
