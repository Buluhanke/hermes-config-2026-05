# 1688.com 反爬机制与编码规格（2026-07-27 实测）

## GBK 编码 — 搜索 URL 乱码根因

**问题**：浏览器地址栏输入中文关键词 → 浏览器用 UTF-8 编码（如"纸箱"→`%E7%BA%B8%E7%AE%B1`）→ 1688 服务器用 GBK 解码 → 乱码

**1688 搜索 URL 格式**：
```
https://s.1688.com/selloffer/offer_search.htm?keywords=纸箱（GBK编码）
```

**错误方式**（CDP `browser_navigate` 直接打开含中文 URL）：
```
browser_navigate("https://s.1688.com/youzhan/search.htm?keywords=20x20x10cm纸箱")
→ 1688 收到 UTF-8 编码 → 解码成乱码 → 搜索结果错误
```

**正确方式**（已验证可行，2026-07-27）：
```
Step 1: browser_navigate("https://s.1688.com/selloffer/offer_search.htm")
        → 搜索页加载完成（无中文 URL 参数，无编码问题）
Step 2: browser_click(e135)  → 点击搜索框 input 元素
Step 3: browser_type(e135, "20x20x10cm纸箱")  → 浏览器内部自动用 GBK 编码提交
Step 4: browser_press(Enter)
→ URL 变成 keywords=20x20x10cm%D6%BD%CF%E4（GBK 编码 ✅）
```

**底层原理**：
- `browser_navigate` → URL 直接发请求，编码由浏览器决定（默认 UTF-8）
- `browser_type` → 内容写入 DOM input，form submit 时浏览器自动选择服务器期望的编码（GBK）

## 1688 反爬机制（2026-07-27 实测）

### CDP 自动化检测
**症状**：CDP 控制的 Chrome 访问 1688 → 验证码拦截页面（`a26352.13672862` 跳转至 punish 页面）

**触发条件**：
- 使用 `--remote-debugging-port` 启动的新 Chrome 实例（即使加 `--disable-blink-features=AutomationControlled`）
- 某些情况下页面 DOM 特征也会触发

**用户手动操作不被检测**：
- 用户自己的 Chrome（`Default` profile，带真实 cookie 和行为指纹）
- 用户已登录状态访问 1688 → 无验证码
- CDP 连接用户 Chrome → 有验证码（因为 CDP 本身被检测为自动化特征）

### 三种解法

**解法 A：连接用户已登录 Chrome**（推荐）
```bash
# 用户 Chrome 已在运行，手动开启调试端口
/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome \
  --remote-debugging-port=9222 \
  --user-data-dir="/Users/aimac/Library/Application Support/Google/Chrome/Default"
```
- cookie 完整继承，无验证码
- 用户需配合启动一次

**解法 B：搜索框输入（绕过编码问题）**
- 直接 `browser_type` 写入搜索框 → 绕过 URL 编码问题
- 已验证可行（2026-07-27）

**解法 C：用户手动搜 → CDP 只读结果**

## 1688 页面不稳定问题

### 搜索结果页跳转到商品详情后，无法回到原搜索页
**现象**：
- 点击商品链接 → 打开新 tab（商品详情）
- `history.back()` 或 `browser_back` → 搜索页重置为默认状态

**正确方式**：
1. 搜索页保持打开（不 close，不 back）
2. 商品详情在新 tab 打开
3. 查完所有商品后，统一关闭商品 tab

### 点击商品链接有时变成图片搜索
**现象**：点击搜索结果中的商品链接 → 跳转到 `air.1688.com/kapp/1688-search/pc-image-search/`（图片搜索页）

**解法**：直接用商品 ID 构造详情页 URL：
```
https://detail.1688.com/offer/{offer_id}.html
```

## 1688 商品详情页规格读取

商品详情页加载后，规格表在 DOM 中：
```javascript
(function(){
  var text = document.body.innerText;
  var has2020 = text.includes('20*20*10') || text.includes('20x20x10') || text.includes('20×20×10');
  var specs = '';
  var specMatch = text.match(/规格[\s\S]{0,2000}/);
  if(specMatch) specs = specMatch[0].substring(0, 1000);
  var priceMatch = text.match(/¥\s*(\d+\.\d+)/);
  return JSON.stringify({has2020, price: priceMatch ? priceMatch[1] : 'not found', specs});
})()
```

价格需要选择具体规格后才显示，页面默认价格是起订量/最低档规格的价格。

## 关键商品链接格式
```
商品详情：https://detail.1688.com/offer/{offer_id}.html
店铺首页：https://winportdetail.1688.com/page/winport.htm?memberId={memberId}
搜索页：  https://s.1688.com/selloffer/offer_search.htm
```

## 江浙沪地区过滤

1688 搜索结果中 Supplier Location 在商品标题下方（如"义乌市 XX 包装有限公司"）。江浙沪关键词：
- 义乌、金华 → 浙江省
- 杭州、苏州、上海 → 江苏省/上海市

大件纸箱远距离运费贵，建议优先选江浙沪供应商。搜索结果中会出现广东、安徽、深圳等外省供应商，需按需过滤。
