# 1688-cli 成品工具（找品链 B 方案，与自建 CDP 脚本互补）

> 调研于 2026-07-27。适用于「不想手搓 CDP 抓取、要结构化 JSON 输出」的场景。

## 安装
```bash
# Node 20+ 已满足；国内走 npmmirror 避开死代理
npm install -g 1688-cli --registry=https://registry.npmmirror.com
# 命令落在 ~/.local/bin/1688（确保该路径在 PATH）
```
- 驱动**本机真实 Chrome**（channel:'chrome'），非合成 Chromium。
- 登录态存独立 `~/.1688/`（与我们的 `~/chrome-cdp-profile` 互不干扰）。
- 登录：`1688 login`（开窗口手机扫码，一次管几周）；`--headed` 兜底过滑块验证。
- 长驻 daemon：首次命令预热浏览器，后续复用，JSON 或 TTY 双模式。

## 核心命令（找品用）
```bash
# 多关键词找品 + 打分 + 供应商背调富集
1688 research "20x20x10cm纸箱" \
  --verified factory \          # 只留源头工厂，丢贸易倒爷
  --province 浙江 \             # 江浙沪过滤
  --exclude-ads \              # 丢 P4P 广告
  --enrich top:5 \             # 自动开前5个详情页抠阶梯价+BSR
  --jsonl                      # 一行一个 JSON，pipe 给脚本

# 其他：search / compare / supplier / image-search / offer / similar
1688 supplier                  # 供应商履约指标背调(BSR)
1688 offer <offerIds...>       # 单/多个商品详情(阶梯价)
1688 image-search <图URL>      # 以图搜款
```
- `--enrich top:N` 就是开详情页抠**阶梯价+MOQ+回头率+发货速度**，比手搓正则稳。

## 与自建 CDP 脚本的关系（不冲突）
| | A 自建 CDP (1688_findchain_v2.py) | B 1688-cli |
|---|---|---|
| Chrome 实例 | 9222 镜像 profile | 独立 ~/.1688 |
| 登录 | 用户扫一次码(镜像) | 用户扫一次码(1688-cli) |
| 强项 | 人肉视角逐个验证、尺寸命中准 | 结构化 BSR 背调、阶梯价解析 |
| 弱项 | 回头率/MOQ 正则剥不干净 | 需另扫一次码 |

**分工**：B 跑结构化拉取当主力；A 当兜底+人工式逐个核对验证层。两者端口/登录态隔离，可并行。

## 其他同类成品（调研时发现的备选）
- `1688-Scraper-MCP`（xiayumu034）：MCP server，DrissionPage + 本地 user_data 持久化，内置阶梯价解析 + 供应商 BSR 背调 + 滑块验证手动过。
- `1688crawler` / `1688Collector`：Python/Selenium 方案，偏重图片采集与详情页深度解析。
