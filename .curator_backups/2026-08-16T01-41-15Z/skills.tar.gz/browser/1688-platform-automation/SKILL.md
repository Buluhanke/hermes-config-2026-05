---
name: 1688-platform-automation
description: "1688.com 浏览器自动化 — GBK编码搜索乱码解决、反爬机制、CDP连接用户Chrome。"
triggers:
  - "1688搜索乱码"
  - "1688 GBK"
  - "1688反爬"
  - "1688自动化"
  - "1688商品查询"
l1: 电商平台
l2: 1688
l3: 自动化
---

# 1688.com 浏览器自动化

## 核心问题：GBK 编码导致搜索乱码

**根因**：1688 中国站搜索页面使用 GBK 编码。浏览器地址栏输入中文 → UTF-8 编码 → 1688 服务器用 GBK 解码 → 乱码。

**错误方式**（`browser_navigate` 直接打开含中文 URL）：
```
browser_navigate("https://s.1688.com/youzhan/search.htm?keywords=20x20x10cm纸箱")
→ 1688 收到 UTF-8 编码 → 解码成乱码 → 搜索结果错误
```

**正确方式**（已验证可行，2026-07-27）：
```
Step 1: browser_navigate("https://s.1688.com/selloffer/offer_search.htm")
        → 搜索页加载（无中文 URL 参数）
Step 2: browser_click(e135)  → 点击搜索框 input
Step 3: browser_type(e135, "20x20x10cm纸箱")  → 浏览器内部自动用 GBK 编码提交
Step 4: browser_press(Enter)
→ URL 变成 keywords=20x20x10cm%D6%BD%CF%E4（GBK ✅）
```

**底层原理**：
- `browser_navigate` → URL 直接发请求，浏览器默认 UTF-8 编码
- `browser_type` → 内容写入 DOM input，form submit 时浏览器自动选择服务器期望的编码（GBK）

## 反爬机制与解法

### 滑块验证码（slider captcha）触发与处理（2026-07-31 新增）

**症状**：`browser_type` + `browser_press(Enter)` 提交搜索后，页面显示"亲，请拖动下方滑块完成验证"。

**根因**：1688 检测到浏览器自动化特征（CDP 指纹），触发 AliWangWang 滑块验证码。这是服务端防御，`Input.dispatchMouseEvent` 模拟拖动**无法通过**。

**触发场景**：
- `browser_type` 写入搜索框 + Enter → 高概率触发
- 搜索结果页频繁翻页 → 也可能触发
- 已登录的 user Chrome 也会触发（CDP 特征未完全隐藏）

**解法（按优先级）**：
1. **用户手动在浏览器完成一次滑块验证**（最快，一劳永逸）
2. **等待**：滑块验证 session 有时效，通常 10-30 分钟自动解除，继续搜索可能仍触发
3. **切换到 1688-cli** 完全绕过浏览器：`1688 research "关键词" --verified factory`（需要登录态）

**判断 SOP**：搜索提交后 `browser_snapshot` 或 `browser_vision` 看到"亲，请拖动下方滑块" → 滑块验证码触发。

### CDP 自动化检测
**症状**：CDP 控制的 Chrome → 验证码拦截（跳转至 `https://www.google.com/sorry/index?continue=...` 或 1688 `punish` 页面）

**触发原因**：
- 直连用户真实 Chrome（`--user-data-dir` 指向 Default profile）= 完整真实指纹（navigator.plugins、canvas fingerprint、WebRTC、字体列表等）
- `cdp_override` stealth 模式只 patch 少量 `navigator` 属性（`webdriver`, `automationControlled`），无法覆盖所有检测维度
- Google/Baidu 的检测远不止 JS 属性——鼠标轨迹、请求时序、headless 特征、IP 行为模型都会被分析

**影响范围（2026-07-28 验证）**：
| 目标站点 | 用户真实 Chrome + CDP | Playwright stealth headless |
|---|---|---|
| Google 搜索 | ❌ CAPTCHA | ✅ 可用 |
| 1688 商品详情页 | ✅ 可用（已登录无验证码） | ✅ 可用 |
| 百度搜索 | ❌ 大概率 CAPTCHA | ✅ 可用 |
| 1688 搜索列表页 | ⚠️ 频繁触发 punish 验证码 | ⚠️ 仍会触发 |

### 五种解法

**解法 A：连接用户已登录 Chrome**（推荐用于 1688 详情页核价）
```bash
/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome \
  --remote-debugging-port=9222 \
  --user-data-dir="/Users/aimac/Library/Application Support/Google/Chrome/Default"
```
- cookie 完整继承，1688 等国内平台无验证码
- ⚠️ **不适用于 Google/百度等搜索引擎自动化**

**解法 B：Playwright stealth headless（适用于 Google 搜索）**
新建完全隔离的 headless 实例，Playwright stealth 模式自动 patch 所有已知检测点：
```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(
        headless=True,
        args=['--disable-blink-features=AutomationControlled',
              '--disable-dev-shm-usage', '--no-sandbox']
    )
    context = browser.new_context(locale='zh-CN', viewport={'width': 1920, 'height': 1080})
    page = context.new_page()
    page.goto('https://www.google.com/search?q=关键词')
```

**解法 C：1688-cli（推荐作为 1688 搜索主力）**
不走浏览器，纯结构化 API，登录态独立 profile，**完全没有验证码问题**：
```bash
1688 research "关键词" --verified factory --province 浙江 --enrich top:10 --jsonl
```
Browser CDP 只用于"逐个点开商品详情页核价格"这个精细操作环节。

**解法 D：搜索框输入（绕过 GBK 编码问题）**
- 直接 `browser_type` 写入搜索框 → form submit 时浏览器自动选择 GBK 编码
- 已验证可行（2026-07-27）
- ⚠️ 仍受反爬检测限制，Google 搜索仍触发 CAPTCHA

**解法 E：用户手动搜 → CDP 只读结果**
用户自己在 Chrome 里搜好，Hermes 只负责读结果 tab 的 DOM。

## 搜索结果页操作规范

### 点击商品后无法 back 回搜索结果
- 点击商品 → 打开新 tab（详情页）
- `history.back()` / `browser_back` → 搜索页重置为默认状态

**正确方式**：
1. 搜索页保持打开（不 close，不 back）
2. 商品详情在新 tab 打开
3. 查完所有商品后，统一关闭商品 tab

### 点击商品链接有时变成图片搜索
**现象**：点击商品 → 跳转到 `air.1688.com/kapp/1688-search/pc-image-search/`

**解法**：直接用商品 ID 构造详情页 URL：
```
https://detail.1688.com/offer/{offer_id}.html
```

## 商品详情页规格读取（CDP 逐个验证）

**关键发现**：搜索结果页的商品链接形态是 `offerId=数字`（不是 `detail.1688.com/offer/数字.html`）。详情页 URL 格式为：
```
https://detail.1688.com/offer/{offer_id}.html
```

**验证目标规格的标准方法**（以 16×16×16cm 为例）：

1. 导航到 `https://detail.1688.com/offer/{id}.html`
2. 找页面中 **商品属性** 区域 → 规格型号表格
3. 在表格中搜索包含目标尺寸的行（如 `16*16*16cm` 或 `16×16×16cm`）
4. 确认该行规格材质（如 `三层特硬B/A瓦`、`3层特硬(中档)`）

**CDP 验证脚本**：
```javascript
(function(){
  var text = document.body.innerText;
  var hasTarget = text.includes('16*16*16cm') || text.includes('16×16×16cm') || text.includes('16x16x16cm');
  var specRows = [];
  document.querySelectorAll('table tr').forEach(function(row){
    var cells = Array.from(row.cells).map(function(c){return c.innerText.trim();});
    if(cells.some(function(c){return c.includes('16') && c.includes('16') && c.includes('16');})){
      specRows.push(cells.join(' | '));
    }
  });
  return JSON.stringify({hasTarget: hasTarget, matchedSpecs: specRows.slice(0,5)});
})()
```

**注意**：商品规格表格在商品属性 tab 下，列结构为 `规格型号 | 规格 | 材质硬度等级`，每行一个规格选项。**不是**用搜索结果页的标题文字判断——标题写的"正方形纸箱"可能根本不含目标尺寸，必须进详情页规格表核实。

## 搜索结果页操作规范（重要更新）

### 点击商品后无法 back 回搜索结果
- 点击商品 → 打开新 tab（详情页）
- `history.back()` / `browser_back` → 搜索页重置为默认状态（推荐商品消失）

**正确方式**：
1. 搜索页保持打开（不 close，不 back）
2. 商品详情在新 tab 打开
3. 通过 `Target.getTargets` 找到新 tab 的 targetId
4. 用 `browser_navigate` 或 `Page.bringToFront` 切到详情 tab 核对规格
5. 查完所有商品后，统一关闭商品 tab

### 从 Target.getTargets 获取真实详情页 URL
当点击商品后，在 CDP `Target.getTargets` 响应里找 `type=page` 且 `title` 含商品名的条目，其 `url` 字段就是真实 `detail.1688.com/offer/{id}.html`。

### ⚠️ 找品链铁律（用户核心纠正，2026-07-27/07-28）

**用户要求的是「登录Chrome → 搜索框输入词 → 1688推荐商品一个个打开 → 核对规格 → 记录链接+价格」的真实链路。绝不允许用 web_search 抓公开结果、或瞎猜商品 URL 充当找品数据。**

- 正确链路：复用已登录的 9222 实例 → `s.1688.com/selloffer/offer_search.htm` → 聚焦搜索框真实输入（GBK 自动编码）→ 回车 → 从推荐卡片抠 offerId → 逐个导航到 `detail.1688.com/offer/{id}.html` → 读规格表核对目标尺寸 → 记录。
- **搜索结果页不在 outerHTML 渲染商品链接**（1MB HTML 里找不到 `detail.1688.com/offer/`），但 `innerText` 有完整商品列表。卡片链接形态是 `offerId=数字`（不是 `detail.1688.com/offer/数字`），须从 `Target.getTargets` 的新 tab 信息里获取真实详情页 URL，或用 offerId 拼装。
- 详情页规格区是完整文本（含全部尺寸如 `16*16*16cm,17*17*17cm,...`），用正则 `16[ *×xX]16[ *×xX]16` 命中目标规格。
- 1688 搜索有反爬验证码（`punish` 页面，滑动验证），**频繁搜索/翻页会触发**。验证码需用户在浏览器里手动完成，或等几分钟再试。
- 搜索结果里的商品 URL 可能已失效（商品下架），碰到 404 是正常现象，换下一家继续。

## 前置动作：browser_navigate 走后台 Chrome，不是用户屏幕（2026-07-31 验证）

**关键区分**：

| 工具 | 控制什么 | 用户能看见吗 |
|------|---------|-----------|
| `browser_navigate` / `browser_snapshot` / `browser_cdp` | CDP 端口 9222 后台 Chrome 实例 | ❌ 看不见 |
| `computer_use` + 地址栏操作 | 用户眼前的 Chrome 窗口 | ✅ 看得见 |

**两条路并行（2026-07-31 实操确认）**：
- **用户可见 Chrome**：`computer_use` → `cmd+l` 全选地址栏 → `type` 输入 URL → `return` 导航。地址栏操作可靠，桌面可见。
- **后台 CDP Chrome**：`browser_navigate` → `detail.1688.com/offer/{id}.html` 直接拿完整快照，规格表/SKU表全部可见，browser_snapshot 含完整 AX tree。

**禁止**：用 `browser_navigate` 充当"打开用户 Chrome"的方式。必须用 `computer_use` 操作用户窗口。

## 前置动作：确保 Chrome 窗口可见

**`open -a "Google Chrome"` 和 `osascript activate` 只能激活后台进程，用户看不到窗口。**

正确方式：用 osascript 脚本设置窗口位置和大小，强制 Chrome 窗口出现：

```applescript
-- /tmp/bring_chrome.scpt
tell application "Google Chrome"
    activate
    set visible of window 1 to true
    set bounds of window 1 to {0, 0, 1440, 900}
end tell
```

```bash
osascript /tmp/bring_chrome.scpt
```

**每次操作前必须确认用户能看到浏览器窗口**。如果用户说"没有"、"看不到"，立即执行上述脚本。

## 江浙沪地区过滤

Supplier Location 在商品标题下方（如"义乌市 XX 包装有限公司"）。江浙沪关键词：义乌、金华、杭州、苏州、上海。

大件纸箱远距离运费贵，优先选江浙沪供应商。

**地区过滤正确方式**：用 URL 的 `province=` 参数，不要把地名加在 keywords 里：
```
# ✅ 正确：province 参数过滤金华
https://s.1688.com/selloffer/offer_search.html?keywords=16x16x16cm纸箱&province=%E9%87%91%E5%8D%8E%E5%B8%82

# ❌ 错误：把金华加在关键词里 → 搜索词被污染，结果全是电子元件/无关商品
https://s.1688.com/selloffer/offer_search.html?keywords=16x16x16cm纸箱金华
```
province 参数值：`金华市=%E9%87%91%E5%8D%8E%E5%B8%82`，`浙江=%E6%B5%99%E6%B1%9F`，`江苏=%E6%B1%9F%E8%A5%BF`，`上海=%E4%B8%8A%E6%B5%B7`

**用户要求**：江浙沪都行，不是只金华。`province=%E6%B5%99%E6%B1%9F`（浙江）即可覆盖金华、杭州、宁波等地。

## 搜索结果页 iframe 攻略（2026-07-31 实战验证）

### `computer_use` 看不见 iframe 内部

1688 搜索结果渲染在深层 iframe 里（~4 层嵌套），`computer_use` 的 AX tree 捕获的是外层 Chrome 窗口 Accessibility Tree，**所有商品卡片、标题、价格、供应商都在 iframe 内部，`computer_use` 完全看不见**。

症状：
- `computer_use capture` AX tree 里有大量 `AXWebArea` / `AXIframe` 条目，但商品标题、价格、供应商不在顶层
- 点击看似商品卡片的 element，实际点到了 iframe 的背景/边框
- iframe 内部链接不可访问

**正确攻略：CDP 注入 JS 提取 offer ID**

1688 搜索页的 offer ID 在链接参数里：`https://detail.1688.com/offer/770605237330.html?offerId=770605237330`。用这个 JS 从搜索页 iframe 提取所有商品 offer ID：

```javascript
(function(){
  var r=[];
  document.querySelectorAll('a').forEach(function(a){
    var m=a.href.match(/offerId=(\d+)/);
    if(m){
      var id=m[1];
      var txt=a.innerText.trim().replace(/\n/g,' ').slice(0,60);
      if(txt.length>5&&!r.find(function(x){return x.id===id}))
        r.push({id:id,text:txt,href:a.href})
    }
  });
  return JSON.stringify(r.slice(0,30))
})()
```

此 JS 在搜索页 iframe 内执行，返回所有带 `offerId=` 的商品卡片链接，包含 id + 标题文本 + href。

**1688 搜索列表页本身不在 outerHTML 直接渲染商品链接**（1MB+ HTML 里没有 `detail.1688.com/offer/`），但 `offerId=` 参数在链接里，上方 JS 能提取。

### CDP 详情页核价 JS（2026-07-31 验证可行）

```javascript
(function(){
  var t=document.title;
  var b=document.body.innerText;
  // b 里包含完整规格表文本（16*16*16cm 等所有尺寸都在里面）
  var hasTarget = b.includes('16*16*16cm') || b.includes('16×16×16cm') || b.includes('16x16x16cm');
  // 提取规格表行
  var rows=[];
  document.querySelectorAll('table tr').forEach(function(row){
    var cells=Array.from(row.cells).map(function(c){return c.innerText.trim()});
    if(cells.length>0) rows.push(cells.join(' | '))
  });
  return JSON.stringify({title:t,hasTarget:hasTarget,specRows:rows.slice(0,20)})
})()
```

实测返回：规格表完整文本（含 `16*16*16cm 内径15.5X15.5X15.3高 126g` 等所有尺寸数据）。

### Google Translate 扩展弹窗（2026-07-31 新增坑点）

Google Translate Chrome 扩展在**每个页面加载时**都会弹出翻译提示（"翻译此页？"），这是一个覆盖层，完全挡住页面交互。

症状：
- 每次 `open -a "Google Chrome" --url` 或页面刷新后，翻译弹窗出现
- AX tree 里看到 `AXWindow '翻译此页？'` 覆盖在主窗口上方
- 所有点击都点不到页面元素，点到了也被弹窗截获
- `computer_use` 的 `element` 索引在弹窗消失后会错位

解法（按优先级）：

1. **用户手动关掉**：用户自己在 Chrome 里把翻译扩展关掉（扩展图标 → 选项 → 关闭该站点）——最彻底，一劳永逸

2. **快捷键绕过**：在页面加载完成后立即按 `Escape`，有时能关掉弹窗

3. **坐标点击关闭**：弹窗的"关闭"按钮在 AX tree 里索引很小（#4 左右），用 `computer_use` 点击 `element=4`（关闭按钮）可以关掉

4. **隔离 Chrome 实例**：用一个没有 Translate 扩展的 Chrome profile 运行自动化：
   ```bash
   "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
     --user-data-dir="$HOME/chrome-automation-profile" \
     --remote-debugging-port=9223
   ```
   注意：这个实例没有1688登录态，需要单独处理登录

**教训**：如果页面操作时发现所有 element 都点不准/弹窗反复出现，先把这个弹窗处理掉再继续。

## 前置动作：browser_navigate 走后台 Chrome，不是用户屏幕（2026-07-31 验证）

**关键区分**：

| 工具 | 控制什么 | 用户能看见吗 |
|------|---------|-----------|
| `browser_navigate` / `browser_snapshot` / `browser_cdp` | CDP 端口 9222 后台 Chrome 实例 | ❌ 看不见 |
| `computer_use` + 地址栏操作 | 用户眼前的 Chrome 窗口 | ✅ 看得见 |

**两条路并行（2026-07-31 实操确认）**：
- **用户可见 Chrome**：`computer_use` → `cmd+l` 全选地址栏 → `type` 输入 URL → `return` 导航。地址栏操作可靠，桌面可见。
- **后台 CDP Chrome**：`browser_navigate` → `detail.1688.com/offer/{id}.html` 直接拿完整快照，规格表/SKU表全部可见，browser_snapshot 含完整 AX tree。

**禁止**：用 `browser_navigate` 充当"打开用户 Chrome"的方式。必须用 `computer_use` 操作用户窗口。

## 前置动作：确保 Chrome 窗口可见

**`open -a "Google Chrome"` 和 `osascript activate` 只能激活后台进程，用户看不到窗口。**

正确方式：用 osascript 脚本设置窗口位置和大小，强制 Chrome 窗口出现：

```applescript
-- /tmp/bring_chrome.scpt
tell application "Google Chrome"
    activate
    set visible of window 1 to true
    set bounds of window 1 to {0, 0, 1440, 900}
end tell
```
```bash
osascript /tmp/bring_chrome.scpt
```

**每次操作前必须确认用户能看到浏览器窗口**。如果用户说"没有"、"看不到"，立即执行上述脚本。

## 江浙沪地区过滤

Supplier Location 在商品标题下方（如"义乌市 XX 包装有限公司"）。江浙沪关键词：义乌，金华、杭州、苏州、上海。

大件纸箱远距离运费贵，优先选江浙沪供应商。

**地区过滤正确方式**：用 URL 的 `province=` 参数，不要把地名加在 keywords 里：

```
# ✅ 正确：province 参数过滤金华
https://s.1688.com/selloffer/offer_search.html?keywords=16x16x16cm纸箱&province=%E9%87%91%E5%8D%8E%E5%B8%82

# ❌ 错误：把金华加在关键词里 → 搜索词被污染，结果全是电子元件/无关商品
https://s.1688.com/selloffer/offer_search.html?keywords=16x16x16cm纸箱金华
```

province 参数值：`金华市=%E9%87%91%E5%8D%8E%E5%B8%82`，`浙江=%E6%B5%99%E6%B1%9F`，`江苏=%E6%B1%9F%E8%A5%BF`，`上海=%E4%B8%8A%E6%B5%B7`

**用户要求**：江浙沪都行，不是只金华。`province=%E6%B5%99%E6%B1%9F`（浙江）即可覆盖金华、杭州、宁波等地。

## ⚠️ 找品链核心工作流（2026-07-31 用户纠正后固化）

**用户原话**：「你根本没看到网页内容，你打开了1688搜索推荐，我们的目的是一个个去打开每个被推荐的商品，找到对应我们需要的商品」

**之前犯的错误**：看到列表页标题就推荐，没有逐个点进详情页核实规格。

**正确找品链**：

1. **整理商品表格**（先读页面，把所有商品标题/价格/供应商/地域整理成表格）
2. **按地域过滤**（江浙沪）→ 剩下候选商品
3. **逐个点进详情页** → CDP Runtime.evaluate 读规格表 → 确认是否有 16*16*16cm
4. **有就记录**：供应商名、价格、链接、阶梯价
5. **没有就继续下一个**

**禁止**：看到列表页标题有"16cm"就直接推荐。不进详情页核实规格尺寸 = 假数据。

**判断步骤**：
- 标题有"正方形/16cm" → 进详情页 ✅
- 标题只有"纸箱"无尺寸 → 进详情页 ✅  
- 标题写了尺寸但不是16*16*16cm → 排除 ❌
- 供应商不在江浙沪 → 排除 ❌

### 逐个核实规格的 JS（已在用户 Chrome CDP 实测可行）

```javascript
// 在详情页执行，提取完整规格表
(function(){
  var text = document.body.innerText;
  var hasTarget = text.includes('16*16*16cm') || text.includes('16×16×16cm');
  var specs = [];
  document.querySelectorAll('table tr').forEach(function(row){
    var cells = Array.from(row.cells).map(function(c){return c.innerText.trim()});
    if(cells.length>0) specs.push(cells.join(' | '))
  });
  return JSON.stringify({title:document.title,hasTarget:hasTarget,specRows:specs.slice(0,20)})
})()
```

返回 `hasTarget: true` 即表示有 16*16*16cm 规格，再从 `specRows` 里找对应行获取价格。

之前的文档写了"CDP 的 Runtime.evaluate 对搜索页 iframe 注入 JS 返回空数组"。

**今日教训**：`computer_use` 的 AX tree 捕获同样是外层 Chrome 窗口的 Accessibility Tree，搜索结果在深层 iframe 里，**`computer_use` 看不见 iframe 内部元素**。

症状：
- `computer_use capture` 返回的 AX tree 里有很多 `AXRole: AXWebArea` / `AXIframe` 条目
- 点击看似商品卡片的 element，实际点到了 iframe 的背景/边框
- iframe 内部链接不可访问

**两条路都不通时的终极解法**：`1688-cli`（见下文），完全绕过浏览器。

## 搜索结果页 iframe 渲染失败的处理

**症状**：`browser_snapshot` 显示页面 DOM 里没有商品列表，只有导航栏和搜索框。1688 搜索结果渲染在深层 iframe 里，`innerText` 有商品标题但 `outerHTML` 里找不到 `detail.1688.com/offer/` 链接。

**解法**：搜索结果页本身不可靠，直接用 `1688-cli` 或 `findchain.py` 拿列表，再对重点商品单独用 CDP 开详情页验证。

**CDP 切到新 tab 验证商品**：从 `Target.getTargets` 获取新 tab 的 targetId，切过去读规格：

```javascript
// 先 Target.getTargets 拿到所有 tab，找到商品详情 tab
// 然后用 Runtime.evaluate 读规格表
(function(){
  var text = document.body.innerText;
  var specs = [];
  document.querySelectorAll('table tr').forEach(function(row){
    var cells = Array.from(row.cells).map(function(c){return c.innerText.trim();});
    if(cells.some(function(c){return c.match(/16[ *×xX]16[ *×xX]16/);})){
      specs.push(cells.join(' | '));
    }
  });
  return JSON.stringify({matchedSpecs: specs.slice(0,5)});
})()
```

## 关键 URL 格式

```
商品详情：https://detail.1688.com/offer/{offer_id}.html
店铺首页：https://winportdetail.1688.com/page/winport.htm?memberId={memberId}
搜索页：  https://s.1688.com/selloffer/offer_search.htm
```

**1688 商品链接形态**：
- 列表页链接：`offerId=736891013614`（在 URL 参数里）
- 详情页 URL：`https://detail.1688.com/offer/736891013614.html`

**从列表页到详情页**：从 JS 提取 offerId 后，拼接 `https://detail.1688.com/offer/{id}.html` 即可直接导航。

## 阶梯价 / 供应商背调（找品 v2 必做）

用户要的不是"起价"而是**真实可下单数据**：
- **阶梯价 + MOQ**：详情页价格表是 `2-99件 ¥X / ≥100件 ¥Y` 形态，纯 `innerText` 正则只能抓到价格碎片（如 `['0','0','3']`）。精确阶梯价/MOQ 要进 SKU 表 DOM 节点抠，或交给 `1688-cli --enrich`。
- **供应商 BSR 背调**：工厂 vs 贸易商，牛头标/超级工厂/实力商家、回头率、发货速度、是否一件代发（先采后付）——这是"找品"的筛选核心维度。`1688-cli research --verified factory --province 浙江 --enrich top:5` 内置这层，比手搓正则稳。
- **打分排序**：命中目标规格(+50) + 江浙沪(+15) + 代发Y(+10) + 超级工厂(+10) + 回头率≥40%(+5)。

## 1688-cli 成品工具（互补，不冲突）

`npm i -g 1688-cli --registry=https://registry.npmmirror.com`（Node 20+）。驱动**本机真实 Chrome** + 独立 `~/.1688` profile + 扫码登录一次管几周，JSON 输出。命令：`1688 research "词" --verified factory --province 浙江 --enrich top:5 --jsonl`。与我们的 CDP 脚本**各自独立 Chrome 实例、各自登录态、不抢端口**，可并行不冲突（A=CDP 人肉验证，B=1688-cli 结构化拉取）。注意：B 需用户单独扫一次码。

`npm i -g 1688-cli --registry=https://registry.npmmirror.com`（Node 20+）。驱动**本机真实 Chrome** + 独立 `~/.1688` profile + 扫码登录一次管几周，JSON 输出。命令：`1688 research "词" --verified factory --province 浙江 --enrich top:5 --jsonl`。与我们的 CDP 脚本**各自独立 Chrome 实例、各自登录态、不抢端口**，可并行不冲突（A=CDP 人肉验证，B=1688-cli 结构化拉取）。注意：B 需用户单独扫一次码。
