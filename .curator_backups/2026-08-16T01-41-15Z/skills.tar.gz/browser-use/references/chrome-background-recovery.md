# Chrome Background Process Recovery

## The Problem

Chrome is running (`ps aux | grep Chrome` shows a PID) but:
- `computer_use app="Google Chrome"` returns "no on-screen window"
- `osascript` reports "No windows"
- `cua-driver get_accessibility_tree` shows Chrome with `windows: []`

Chrome has open tabs (confirmed by the user) but all windows are minimized or hidden. macOS accessibility APIs do not surface hidden/minimized windows in the AX tree.

## Full Recovery Sequence

### Step 1: Get Chrome PID
```bash
ps aux | grep "Chrome" | grep -v "Helper\|crashpad\|grep"
# or
cua-driver get_accessibility_tree | grep -A5 '"Google Chrome"'
```

### Step 2: Activate Chrome + Open/Focus Window (osascript)
```applescript
tell application "Google Chrome"
    activate
    delay 1
    if (count of windows) = 0 then
        make new window
    end if
    set URL of active tab of window 1 to "https://design.penpot.app/#/settings/integrations"
    delay 2
end tell
return "Done"
```

### Step 3: Restart cua-driver daemon (rebuild AX session)
```bash
# Kill existing daemon
pkill -f "cua-driver serve"
sleep 1

# Start fresh daemon
/Applications/CuaDriver.app/Contents/MacOS/cua-driver serve \
  --socket /Users/aimac/Library/Caches/cua-driver/cua-driver.sock &
sleep 3

# Verify socket
ls -la /Users/aimac/Library/Caches/cua-driver/cua-driver.sock
```

### Step 4: Verify Chrome now visible to AX
```bash
cua-driver get_accessibility_tree | grep -A10 '"Google Chrome"'
# Should now show windows: [WID] instead of windows: []
```

### Step 5: Now computer_use will work
```python
# First capture
computer_use(action="capture", app="com.google.Chrome", mode="som")
# Should return element overlays + AX index
```

## Why This Happens

Chrome is unusual because:
1. It runs as a **launched daemon** even when no user windows are open
2. All windows can be minimized to the dock
3. The macOS AX API only enumerates visible windows
4. `computer_use` and cua-driver both route through the AX API, so hidden Chrome = no elements

## Important Distinction: AX Window vs. Tab

Even after recovery, Chrome **tab content** (especially SPAs like Penpot, Figma, etc.) runs in a **renderer subprocess** that is AX-isolated from the parent Chrome process. This means:
- The parent Chrome window appears in the AX tree (toolbar, address bar, tab bar — native elements)
- The **web content inside each tab** does NOT appear in the AX tree (empty `nodes: []`)
- This is Chrome's security boundary, not a permissions issue

For SPA content extraction, use `web_extract`, `osascript do JavaScript`, or a dedicated CDP connection to the tab's renderer target instead of AX.

## Google Translate Popup

Chrome's "Translate this page?" popup appears on nearly every page navigation (especially non-English sites like Penpot). It blocks access to page content. Dismiss it with:

```applescript
tell application "System Events" to key code 53
delay 0.3
```

Or via osascript:
```bash
osascript -e 'tell application "System Events" to key code 53' -e 'delay 0.3'
```

The popup has a predictable `AXWindow` position near the top-right (bounds ~[1353, 110, 284, 87]). When `computer_use capture` shows `window_title: "翻译此页？"` as the AXWindow label, the popup is blocking the actual page. The parent Chrome window title can still be `Integrations - Penpot` even with the popup on top — dismiss it first before any further operations.

## Google Translate Popup

Chrome's "Translate this page?" popup appears on nearly every page navigation (especially non-English sites like Penpot). It blocks access to the page content. Dismiss it with:

```applescript
tell application "System Events" to key code 53
delay 0.3
```

Or via osascript:
```bash
osascript -e 'tell application "System Events" to key code 53' -e 'delay 0.3'
```

The popup has a predictable `AXWindow` position near the top-right of the screen (bounds ~[1353, 110, 284, 87]). When `computer_use capture` shows `window_title: "翻译此页？"` as the AXWindow label, the popup is blocking the actual page.
