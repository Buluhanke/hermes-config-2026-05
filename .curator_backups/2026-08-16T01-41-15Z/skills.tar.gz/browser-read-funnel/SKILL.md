---
name: browser-read-funnel
description: |
  统一网页内容读取漏斗 — Firecrawl + Scrapling + Crawl4AI + 截图 OCR
  解决 Shadow DOM、Canvas、WebGL、懒加载、反爬等所有内容读取盲区。
  用法：python3 scripts/read_page.py <url> [options]
triggers:
  - "读取网页内容"
  - "extract page content"
  - "shadow DOM"
  - "canvas 表格"
  - "网页读不到"
  - "页面内容提取"
  - "browser-read-funnel"
l1: browser
l2: read-funnel
l3: core
---

# Browser Read Funnel — 100% 网页内容读取方案

## 工具栈（4 层漏斗）

| 工具 | 延迟 | 费用 | 强项 | 弱项 |
|------|------|------|------|------|
| **Firecrawl** | 1-3s | API 额度 | 公开 URL、抗反爬、零配置 | Shadow DOM 不稳定 |
| **Scrapling** | 3-8s | 免费 | stealth 浏览器、Cloudflare bypass、动态页面 | 不能处理 closed Shadow DOM |
| **Crawl4AI** | 5-15s | 免费 | Shadow DOM force-open、Canvas 截图+OCR、本地完全可控 | 需要浏览器二进制 |
| **截图 OCR** | 10-20s | 免费 | Canvas/WebGL 兜底 | OCR 准确率有限 |

## 读取优先级

```
URL 输入
  ↓
Firecrawl /scrape（快速，公开 URL）
  ↓ 失败
Scrapling（stealth 动态页面）
  ↓ 失败
Crawl4AI（深度，含 flatten_shadow_dom）
  ↓ 仍失败
截图 → Tesseract OCR（最终降级）
```

## 使用方式

### CLI（直接用）

```bash
# 默认 auto 模式（全漏斗逐层尝试）
python3 ~/.hermes/skills/browser-read-funnel/scripts/read_page.py https://example.com

# 强制指定工具
python3 ~/.hermes/skills/browser-read-funnel/scripts/read_page.py https://example.com --force firecrawl
python3 ~/.hermes/skills/browser-read-funnel/scripts/read_page.py https://example.com --force crawl4ai
python3 ~/.hermes/skills/browser-read-funnel/scripts/read_page.py https://example.com --force scrapling

# 开启 Shadow DOM 递归展开（Crawl4AI 专用）
python3 ~/.hermes/skills/browser-read-funnel/scripts/read_page.py https://example.com --shadow-dom

# 输出到文件
python3 ~/.hermes/skills/browser-read-funnel/scripts/read_page.py https://example.com -o output.md

# JSON 输出（程序调用）
python3 ~/.hermes/skills/browser-read-funnel/scripts/read_page.py https://example.com -f json
```

### Python API（Hermes 直接调用）

```python
from browser_read_funnel import read_page, ReadResult

# 方式 1：自动选择最佳工具
result: ReadResult = await read_page(
    url="https://example.com",
    prefer="auto"  # 默认，逐层尝试
)

# 方式 2：强制某个工具
result = await read_page(
    url="https://example.com",
    prefer="crawl4ai",
    flatten_shadow_dom=True,  # Crawl4AI 专用
    timeout=60,
)

print(result.success)
print(result.markdown)
print(result.via)   # "🔥 Firecrawl（云端）" 等
print(result.error)  # 失败原因
```

## 各层详解

### 1. Firecrawl（云端，第一层）

- **用途**：公开 URL 的快速读取，Hermes 内置 `web_extract` 就是这个 backend
- **API Key**：已存在于 `~/.hermes/.env`：`FIRECRAWL_API_KEY=fc-a89...`
- **适用**：普通新闻、博客、文档、GitHub 等
- **不适用**：Shadow DOM（ChatGPT、DeepSeek 等 AI 站点的对话内容）

### 2. Scrapling（本地，第二层）

- **用途**：绕过 Cloudflare 和其他反爬机制，stealth 浏览器模拟真实用户
- **安装状态**：在 optional-skills 目录已安装
- **适用**：需要登录的页面、Cloudflare 拦截页面、简单 SPA
- **不适用**：closed Shadow DOM（shadow root 为 close 状态）

### 3. Crawl4AI（本地，第三层）

- **用途**：Shadow DOM 专用，`flatten_shadow_dom=True` 强制展开所有 shadow root
- **版本**：0.9.2（Hermes venv 已装）
- **安装命令**：`python3 -m pip install -U crawl4ai`
- **浏览器依赖**：`python3 -m playwright install --with-deps chromium`（setup CLI 不存在）
- **CLI 入口**：`node bin/omniroute.mjs`（OmniRoute 捆绑）；Crawl4AI 无独立 CLI，用 Python API
- **适用**：ChatGPT、DeepSeek、豆包等 AI 站点的对话内容，企业微信表格等复杂组件
- **不适用**：Canvas/WebGL 纹理文字（需降级到 OCR）
- **⚠️ OmniRoute 捆绑的 better-sqlite3 与 Node 22.23.1 ABI 不兼容**：导致 OmniRoute DB 探针循环失败，所有 API 500。独立 venv 内 `import crawl4ai` 正常，不受影响。

### 4. 截图 OCR（最终降级）

- **用途**：Canvas 渲染的表格、图表、WebGL 纹理等连 Crawl4AI 都无法提取的内容
- **依赖**：Chrome CDP（`--remote-debugging-port=9222`）+ Tesseract OCR
- **适用**：企业微信智能表格（canvas 渲染）、游戏页面、图表截图

## 降级链实现

```
read_page(url, prefer="auto")
  │
  ├─ firecrawl.scrape(url)       → 成功 → return markdown
  │
  ├─ scrapling.Paparazzi.fetch()  → 成功 → return markdown
  │
  ├─ crawl4ai.arun(url,
  │      flatten_shadow_dom=True,
  │      screenshot=True)
  │                              → 成功 → return markdown
  │
  └─ screenshot → Tesseract OCR
       └─ return ocr_text
```

## 已知限制

| 限制 | 原因 | 状态 |
|------|------|------|
| Cross-origin iframe | 同源策略，JS 无法穿透 | ❌ 无解 |
| 端到端加密内容 | 物理上不可解密 | ❌ 不应读 |
| CAPTCHA | 需要人机验证 | ❌ 不应绕 |
| WebGL 纹理文字 | OCR 也读不到 | ⚠️ 降级链尽头 |

## 升级能力

封装后各层可独立升级，不影响整体漏斗：

| 升级方向 | 命令 | 影响 |
|----------|------|------|
| Firecrawl 版本 | `pip install -U firecrawl-py` | 全局生效 |
| Crawl4AI 版本 | `pip install -U crawl4ai` | 自动兼容 |
| Scrapling 版本 | `pip install -U scrapling` | 自动兼容 |
| 加 Spider API | 加 `--spider` 参数 | 只需加一个新函数 |
| 加 browser-use | 加 `--agent` 参数 | 全新模块，不动现有链 |

## 验证

```bash
# 测试 Firecrawl
python3 -c "
from firecrawl import Firecrawl
import pathlib
key = next(l for l in pathlib.Path.home().joinpath('.hermes/.env').read_text().splitlines() if l.startswith('FIRECRAWL_API_KEY=')).split('=',1)[1].strip()
fc = Firecrawl(api_key=key)
doc = fc.scrape('https://example.com', formats=['markdown'])
print('✅ Firecrawl:', doc.markdown[:100])
"

# 测试 Crawl4AI
python3 -c "
from crawl4ai import AsyncWebCrawler, CrawlerRunConfig
import asyncio
async def t():
    async with AsyncWebCrawler() as c:
        r = await c.arun('https://example.com', config=CrawlerRunConfig(flatten_shadow_dom=True))
        print('✅ Crawl4AI:', r.markdown[:100])
asyncio.run(t())
"

# 快速功能测试（example.com）
python3 ~/.hermes/skills/browser-read-funnel/scripts/read_page.py https://example.com
```
